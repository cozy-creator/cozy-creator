//! Owned byte sources for placement. TensorFS keeps verified descriptors and checkpoint
//! source context, then runs every transfer through the same host/device read engine.

use std::collections::HashMap;
use std::fs::File;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering::{AcqRel, Relaxed}};
use std::sync::{Arc, Mutex};

pub use super::{ItemSource, ObjectRange};
use super::{Copy, Dst, Issued, ReadControl, ReadOpts, ReadStats, Src};
use crate::failure::{Failure, Kind};
use crate::format::ObjectRef;

#[derive(Debug, Clone)]
pub struct Item {
    pub offset: u64,
    pub len: u64,
    pub source: ItemSource,
    pub part_end: bool,
}

/// One destination's items, each at its offset less `origin`.
#[derive(Clone, Copy, Debug)]
pub struct Placement<'a> {
    pub items: &'a [Item],
    pub origin: u64,
    pub dst: Dst,
}

#[derive(Debug, Default)]
pub struct IoTally {
    pub cached_bytes: AtomicU64,
    pub direct_bytes: AtomicU64,
    pub buffered_bytes: AtomicU64,
    pub inline_bytes: AtomicU64,
    pub direct_refused: AtomicU64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Mode {
    Cache,
    Buffered,
    Cached,
}

#[derive(Debug, thiserror::Error)]
pub enum Error {
    #[error(transparent)]
    Source(#[from] Failure),
    #[error(transparent)]
    Read(#[from] super::Error),
}
pub type Result<T> = std::result::Result<T, Error>;

mod raw;
pub use raw::{RawFill, RawRead, RawReadFacts};

// The plan owns every file/inline source that a borrowed engine copy refers to.
// It is shared by joined reads and the owned raw submission path.
enum OwnedSource {
    Zero,
    File(Arc<File>, u64),
    Inline(Arc<[u8]>),
}
struct OwnedCopy {
    src: OwnedSource,
    dst: Dst,
}
impl OwnedCopy {
    fn borrowed(&self) -> Copy<'_> {
        Copy {
            src: match &self.src {
                OwnedSource::Zero => Src::Zero,
                OwnedSource::File(file, offset) => Src::File(file, *offset),
                OwnedSource::Inline(bytes) => Src::Host(bytes.as_ptr()),
            },
            dst: self.dst,
        }
    }
}
struct ReadPlan {
    copies: Vec<OwnedCopy>,
    placement: Vec<usize>,
    inline: u64,
    bytes: u64,
}

fn invalid(detail: impl Into<String>) -> Error {
    Failure {
        kind: Kind::Invalid,
        detail: detail.into(),
    }
    .into()
}

pub struct Source {
    #[cfg(feature = "store")]
    view: Option<super::view::View>,
    #[cfg(feature = "store")]
    _checkpoint: Option<crate::Checkpoint>,
    files: Mutex<HashMap<String, Arc<File>>>,
    direct_io: bool,
}

impl Source {
    pub fn files(files: Vec<(ObjectRef, File)>, direct_io: bool, _plane: usize) -> Source {
        Source {
            #[cfg(feature = "store")]
            view: None,
            #[cfg(feature = "store")]
            _checkpoint: None,
            files: Mutex::new(
                files
                    .into_iter()
                    .map(|(o, f)| (o.sha256, Arc::new(f)))
                    .collect(),
            ),
            direct_io,
        }
    }

    /// Retain metadata and the source context. No chunk opens or downloads until a read.
    #[cfg(feature = "store")]
    pub(crate) fn checkpoint(view: &super::view::View, direct_io: bool, checkpoint: crate::Checkpoint) -> Source {
        let mut source = Self::files(Vec::new(), direct_io, 0);
        source.view = Some(view.clone());
        source._checkpoint = Some(checkpoint);
        source
    }

    #[cfg(feature = "store")]
    fn load(&self, objects: &[ObjectRef]) -> Result<()> {
        if let Some(view) = &self.view {
            let missing = {
                let files = self.files.lock().unwrap();
                objects
                    .iter()
                    .filter(|o| !files.contains_key(&o.sha256))
                    .cloned()
                    .collect::<Vec<_>>()
            };
            if !missing.is_empty() {
                let opened = view.files_for(&missing)?;
                self.files
                    .lock()
                    .unwrap()
                    .extend(opened.into_iter().map(|(o, f)| (o.sha256, Arc::new(f))));
            }
        }
        Ok(())
    }

    /// Verify every object is locally present, opening and caching its descriptor exactly as
    /// a read would. On a local-only source a missing object errors here, before any GPU work,
    /// so a caller can refuse and fall back to a fetch-capable read. The opened files are
    /// retained, so a following read through this source reuses these verified descriptors.
    #[cfg(feature = "store")]
    pub fn verify_local(&self, objects: &[ObjectRef]) -> Result<()> {
        self.load(objects)
    }

    fn file(&self, object: &ObjectRef) -> Result<Arc<File>> {
        if let Some(file) = self.files.lock().unwrap().get(&object.sha256).cloned() {
            return Ok(file);
        }
        Err(invalid(format!(
            "{}: source has no verified file",
            object.sha256
        )))
    }

    pub fn resident(&self, obj: &ObjectRef, _tally: &IoTally) -> Result<bool> {
        #[cfg(feature = "store")]
        self.load(std::slice::from_ref(obj))?;
        let file = self.file(obj)?;
        Ok(platform::durable::cached(&file, 0, obj.length).unwrap_or(false))
    }

    /// Asks the kernel to read `items`' object bytes into the page cache ahead of their fills
    /// (`POSIX_FADV_WILLNEED`, Linux; elsewhere nothing): host RAM is the page cache. Best effort.
    pub fn readahead(&self, items: &[Item]) -> Result<()> {
        #[cfg(feature = "store")]
        {
            let objects: std::collections::BTreeMap<_, _> = items.iter().filter_map(|i| match &i.source {
                ItemSource::Object(range) => Some((range.obj.sha256.clone(), range.obj.clone())),
                ItemSource::Inline(_) => None,
            }).collect();
            self.load(&objects.into_values().collect::<Vec<_>>())?;
        }
        for item in items {
            if let ItemSource::Object(range) = &item.source {
                let file = self.file(&range.obj)?;
                #[cfg(target_os = "linux")]
                // SAFETY: advice on a descriptor this source holds open.
                unsafe {
                    use std::os::fd::AsRawFd;
                    libc::posix_fadvise(file.as_raw_fd(), range.off as libc::off_t, range.len as libc::off_t, libc::POSIX_FADV_WILLNEED);
                }
                #[cfg(not(target_os = "linux"))]
                let _ = file;
            }
        }
        Ok(())
    }

    /// Transfer a placement range. Uncovered padding is zeroed through the same engine.
    ///
    /// # Safety
    /// As [`Source::read_placements`].
    pub unsafe fn read_items(
        &self,
        items: &[Item],
        origin: u64,
        dst: Dst,
        threads: usize,
        mode: Mode,
        tally: &IoTally,
    ) -> Result<ReadStats> {
        // SAFETY: inherited from caller.
        unsafe {
            self.read_placements(&[Placement { items, origin, dst }], threads, mode, tally, None)
        }
    }

    /// Transfer many placement ranges in one engine read, so it pipelines across all of them.
    /// Uncovered padding is zeroed through the same engine. `issued` hears of each device
    /// placement (its index and the engine's streams) once all its copies are issued, before
    /// the read returns.
    ///
    /// # Safety
    /// Each `dst` is exclusively writable for its length; its selected item ranges lie inside it.
    /// On CUDA error, retain device destination owners until `super::drain` proves completion.
    /// Inline host bytes use owned engine staging and are not borrowed by pending GPU work.
    pub unsafe fn read_placements(
        &self,
        placements: &[Placement],
        threads: usize,
        mode: Mode,
        tally: &IoTally,
        issued: Option<Issued>,
    ) -> Result<ReadStats> {
        // SAFETY: identical source/destination contract; ordinary reads are not canceled.
        unsafe { self.read_controlled(placements, threads, mode, tally, issued, None) }
    }

    /// The same bounded device read with cooperative cancellation between staged pieces.
    /// Already submitted copies are joined before an ordinary cancellation is returned.
    ///
    /// # Safety
    /// The destination and owner requirements are exactly `read_placements`'s. On an error,
    /// retain device destinations until `io::drain` proves completion; never infer it from
    /// cancellation alone. Host destinations are read on TensorFS threads and stop between pieces.
    pub unsafe fn read_placements_cancelable(
        &self,
        placements: &[Placement],
        threads: usize,
        mode: Mode,
        tally: &IoTally,
        cancel: &ReadControl,
    ) -> Result<ReadStats> {
        // SAFETY: identical checked read contract, with no issue observer.
        unsafe { self.read_placements_cancelable_observed(placements, threads, mode, tally, cancel, None) }
    }

    /// The same checked cancelable read, with an optional issue-time observer.
    /// `issued` is notification only, not a completion or successful-read certificate.
    /// The callback must not block or re-enter the engine.
    ///
    /// # Safety
    /// Exactly the source/destination contract of [`Source::read_placements_cancelable`].
    pub unsafe fn read_placements_cancelable_observed(
        &self,
        placements: &[Placement],
        threads: usize,
        mode: Mode,
        tally: &IoTally,
        cancel: &ReadControl,
        issued: Option<Issued>,
    ) -> Result<ReadStats> {
        // SAFETY: the caller retains the same sources and destinations through checked completion.
        unsafe { self.read_controlled(placements, threads, mode, tally, issued, Some(cancel)) }
    }

    fn plan_placements(&self, placements: &[Placement<'_>]) -> Result<ReadPlan> {
        #[cfg(feature = "store")]
        {
            let wanted = placements
                .iter()
                .flat_map(|p| p.items)
                .filter_map(|item| match &item.source {
                    ItemSource::Object(range) => {
                        Some((range.obj.sha256.clone(), range.obj.clone()))
                    }
                    ItemSource::Inline(_) => None,
                })
                .collect::<std::collections::BTreeMap<_, _>>()
                .into_values()
                .collect::<Vec<_>>();
            self.load(&wanted)?;
        }
        let mut files = HashMap::new();
        for item in placements.iter().flat_map(|p| p.items) {
            if let ItemSource::Object(range) = &item.source {
                files
                    .entry(range.obj.sha256.clone())
                    .or_insert(self.file(&range.obj)?);
            }
        }
        let mut copies = Vec::new();
        // Each copy's placement.
        let mut of = Vec::new();
        let mut inline = 0;
        for (p, &Placement { items, origin, dst }) in placements.iter().enumerate() {
            // Each placement's copies in destination order, gaps included, so contiguous runs
            // merge (`coalesce`).
            let mut ordered: Vec<(u64, OwnedCopy)> = Vec::with_capacity(items.len() + 1);
            let mut intervals = Vec::with_capacity(items.len());
            for item in items {
                if let ItemSource::Object(range) = &item.source {
                    if range.len != item.len
                        || range
                            .off
                            .checked_add(range.len)
                            .is_none_or(|n| n > range.obj.length)
                    {
                        return Err(invalid("object range exceeds its verified source"));
                    }
                }
                let start = item
                    .offset
                    .checked_sub(origin)
                    .ok_or_else(|| invalid("item begins before destination"))?;
                let end = start
                    .checked_add(item.len)
                    .ok_or_else(|| invalid("item range overflows"))?;
                if end > dst.len() as u64 {
                    return Err(invalid("item exceeds destination"));
                }
                intervals.push((start, end));
                let src = match &item.source {
                    ItemSource::Object(range) => OwnedSource::File(Arc::clone(&files[&range.obj.sha256]), range.off),
                    ItemSource::Inline(bytes) => {
                        if bytes.len() as u64 != item.len {
                            return Err(invalid("inline length differs from item"));
                        }
                        inline += item.len;
                        OwnedSource::Inline(Arc::clone(bytes))
                    }
                };
                ordered.push((start, OwnedCopy {
                    src,
                    dst: dst.slice(start as usize, item.len as usize),
                }));
            }
            intervals.sort_unstable();
            let mut cursor = 0;
            for (start, end) in intervals {
                if start == end {
                    continue;
                }
                if start < cursor {
                    return Err(invalid("placement items overlap"));
                }
                if start > cursor {
                    ordered.push((cursor, OwnedCopy {
                        src: OwnedSource::Zero,
                        dst: dst.slice(cursor as usize, (start - cursor) as usize),
                    }));
                }
                cursor = end;
            }
            if cursor < dst.len() as u64 {
                ordered.push((cursor, OwnedCopy {
                    src: OwnedSource::Zero,
                    dst: dst.slice(cursor as usize, dst.len() - cursor as usize),
                }));
            }
            ordered.sort_by_key(|(at, _)| *at);
            of.resize(of.len() + ordered.len(), p);
            copies.extend(ordered.into_iter().map(|(_, c)| c));
        }
        Ok(ReadPlan {
            copies,
            placement: of,
            inline,
            bytes: placements.iter().flat_map(|p| p.items).map(|item| item.len).sum(),
        })
    }

    unsafe fn read_controlled(
        &self,
        placements: &[Placement],
        threads: usize,
        mode: Mode,
        tally: &IoTally,
        issued: Option<Issued>,
        cancel: Option<&ReadControl>,
    ) -> Result<ReadStats> {
        let plan = self.plan_placements(placements)?;
        let copies = plan.copies.iter().map(OwnedCopy::borrowed).collect();
        let of = &plan.placement;
        let (copies, firsts) = super::coalesce(copies);
        // Each run's placements, and the runs each placement waits for.
        let runs: Vec<Vec<usize>> = (0..firsts.len())
            .map(|r| {
                let mut ps = of[firsts[r]..firsts.get(r + 1).copied().unwrap_or(of.len())].to_vec();
                ps.dedup();
                ps
            })
            .collect();
        let left: Vec<AtomicUsize> = (0..placements.len()).map(|_| AtomicUsize::new(0)).collect();
        runs.iter().flatten().for_each(|&p| _ = left[p].fetch_add(1, Relaxed));
        let run_issued = |r: usize, streams: &[usize]| {
            for &p in &runs[r] {
                if left[p].fetch_sub(1, AcqRel) == 1 {
                    issued.expect("only asked with a listener")(p, streams);
                }
            }
        };
        let opts = ReadOpts {
            threads,
            direct: self.direct_io && mode == Mode::Cache,
            ..ReadOpts::default()
        };
        // SAFETY: item ranges and destination bounds checked above; caller supplies exclusivity.
        let mut stats = match cancel {
            // SAFETY: the same checked items and destinations stay owned for both engine calls.
            Some(cancel) => unsafe { super::read_staged_cancelable(&copies, &opts, cancel, issued.map(|_| &run_issued as Issued)) }?,
            // SAFETY: as above; ordinary reads keep their existing issue observer.
            None => unsafe { super::read_staged(&copies, &opts, issued.map(|_| &run_issued as Issued)) }?,
        };
        stats.bytes = plan.bytes;
        tally.direct_bytes.fetch_add(stats.direct, Relaxed);
        tally.inline_bytes.fetch_add(plan.inline, Relaxed);
        if mode == Mode::Buffered {
            tally.buffered_bytes.fetch_add(stats.cached, Relaxed);
        } else {
            tally.cached_bytes.fetch_add(stats.cached, Relaxed);
        }
        Ok(stats)
    }

    /// # Safety
    /// `dst` is exclusively writable for `item.len` bytes.
    pub unsafe fn read_item(
        &self,
        item: &Item,
        dst: *mut u8,
        mode: Mode,
        tally: &IoTally,
    ) -> Result<()> {
        // SAFETY: inherited from caller.
        unsafe {
            self.read_items(
                std::slice::from_ref(item),
                item.offset,
                Dst::Host {
                    ptr: dst,
                    len: item.len as usize,
                },
                1,
                mode,
                tally,
            )
        }
        .map(|_| ())
    }
}
