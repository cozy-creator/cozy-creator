//! Bounded pinned host staging; every native device buffer belongs to Varena working memory.

use std::collections::{BTreeMap, VecDeque};
use std::io;
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering::{AcqRel, Relaxed}};
use std::sync::{Arc, Mutex, OnceLock};
use std::time::Instant;

use super::cuda::{self, CUcontext, CUevent, CUstream, CtxGuard};
use super::{host, Copy, Dst, Error, Issued, ReadControl, ReadOpts, ReadStats, Src};

mod owned;
pub(super) use owned::OwnedRead;

const PIECE: usize = 2 << 20;
const READERS: usize = 8;
/// Slots each reader owns: one fills while the other's copy lands, and both stay in its caches.
/// A shared pool (LIFO or FIFO) measured 8-20% slower warm H2D.
const RING: usize = 2;
const STAGING: usize = READERS * RING;
const STREAMS: usize = 4;

fn failed(copy: usize, error: cuda::Error) -> Error {
    let kind = match error {
        cuda::Error::Cuda {
            code: cuda::ERROR_OUT_OF_MEMORY,
            ..
        } => io::ErrorKind::OutOfMemory,
        cuda::Error::Allocation(varena::Error::OutOfMemory { .. }) => io::ErrorKind::OutOfMemory,
        cuda::Error::Allocation(varena::Error::Unsupported(_)) | cuda::Error::CudaUnavailable(_) => io::ErrorKind::Unsupported,
        _ => io::ErrorKind::Other,
    };
    Error {
        copy,
        source: io::Error::new(kind, error),
    }
}

pub(super) struct Event {
    ctx: CUcontext,
    raw: CUevent,
    timing: bool,
    release_failed: bool,
}

impl Event {
    pub(super) fn new(ctx: CUcontext, timing: bool) -> cuda::Result<Event> {
        let _ctx = CtxGuard::enter(ctx)?;
        let mut raw = std::ptr::null_mut();
        // SAFETY: `raw` is a writable out-pointer and the event's context is current.
        cuda::check("cuEventCreate", unsafe {
            (cuda::driver()?.event_create)(
                &mut raw,
                if timing {
                    cuda::EVENT_DEFAULT
                } else {
                    cuda::EVENT_DISABLE_TIMING
                },
            )
        })?;
        Ok(Event {
            ctx,
            raw,
            timing,
            release_failed: false,
        })
    }
    pub(super) fn record(&self, stream: CUstream) -> cuda::Result<()> {
        let _ctx = CtxGuard::enter(self.ctx)?;
        // SAFETY: a live event and stream of this context, which is current.
        cuda::check("cuEventRecord", unsafe {
            (cuda::driver()?.event_record)(self.raw, stream)
        })
    }
    fn sync(&self) -> cuda::Result<()> {
        let _ctx = CtxGuard::enter(self.ctx)?;
        // SAFETY: a live event of this context, which is current.
        cuda::check("cuEventSynchronize", unsafe {
            (cuda::driver()?.event_synchronize)(self.raw)
        })
    }
    pub(super) fn wait_on(&self, stream: CUstream) -> cuda::Result<()> {
        let _ctx = CtxGuard::enter(self.ctx)?;
        // SAFETY: both handles are retained in this context; record precedes every wait.
        cuda::check("cuStreamWaitEvent", unsafe {
            (cuda::driver()?.stream_wait_event)(stream, self.raw, 0)
        })
    }
    pub(super) fn release_checked(&mut self) -> cuda::Result<()> {
        if self.release_failed {
            return Err(cuda::Error::CudaUnavailable(
                "event release was already unproven".into(),
            ));
        }
        if self.raw.is_null() {
            return Ok(());
        }
        self.release_failed = true;
        let _ctx = CtxGuard::enter(self.ctx)?;
        // SAFETY: the sole owner destroys this event once; failure forbids any retry.
        cuda::check("cuEventDestroy(checked)", unsafe {
            (cuda::driver()?.event_destroy)(self.raw)
        })?;
        self.raw = std::ptr::null_mut();
        self.release_failed = false;
        Ok(())
    }
    fn since(&self, start: &Event) -> cuda::Result<u64> {
        let mut ms = 0.0f32;
        // SAFETY: `ms` is writable and both events are live.
        cuda::check("cuEventElapsedTime", unsafe {
            (cuda::driver()?.event_elapsed_time)(&mut ms, start.raw, self.raw)
        })?;
        Ok((ms as f64 * 1e6) as u64)
    }
}

impl Drop for Event {
    fn drop(&mut self) {
        if self.release_failed || self.raw.is_null() {
            return;
        }
        if let (Ok(d), Ok(_ctx)) = (cuda::driver(), CtxGuard::enter(self.ctx)) {
            // SAFETY: the event is live in this context, which is current; destroyed once, here.
            unsafe { (d.event_destroy)(self.raw) };
        }
    }
}

struct Slot {
    ptr: *mut u8,
    done: Event,
    pending: bool,
    recorded: bool,
}

impl Slot {
    fn new(ctx: CUcontext) -> cuda::Result<Slot> {
        let done = Event::new(ctx, false)?;
        let mut ptr = std::ptr::null_mut();
        // SAFETY: `ptr` is a writable out-pointer and the slot's context is current.
        cuda::check("cuMemHostAlloc", unsafe {
            (cuda::driver()?.mem_host_alloc)(&mut ptr, PIECE, cuda::MEMHOSTALLOC_PORTABLE)
        })?;
        Ok(Slot {
            ptr: ptr.cast(),
            done,
            pending: false,
            recorded: false,
        })
    }
}

// SAFETY: pinned host memory and an event of the engine's context, used only with it entered.
unsafe impl Send for Slot {}

impl Drop for Slot {
    fn drop(&mut self) {
        if let (Ok(d), Ok(_ctx)) = (cuda::driver(), CtxGuard::enter(self.done.ctx)) {
            if self.pending && (!self.recorded || self.done.sync().is_err()) {
                // The driver may still touch this allocation. Retain it until process exit
                // rather than free an unproved in-flight stage during unwinding.
                return;
            }
            // SAFETY: this slot allocated `ptr` and every copy using it has completed (checked above).
            unsafe { (d.mem_free_host)(self.ptr.cast()) };
        }
    }
}

/// The CPUs of the GPU's own NUMA node that this process may use. Readers run there and staging
/// is allocated there: on a two-socket EPYC, readers and slots left to the scheduler measured
/// 64-94% of the H2D ceiling from run to run, kept local 92-94%.
#[derive(Clone, Copy)]
struct Near(#[cfg(target_os = "linux")] Option<libc::cpu_set_t>);

impl Near {
    #[cfg(target_os = "linux")]
    fn of(device: i32) -> Near {
        let list = super::metrics::pci_address(device).and_then(|pci| {
            std::fs::read_to_string(format!("/sys/bus/pci/devices/{pci}/local_cpulist")).ok()
        });
        // SAFETY: plain C structs and calls on this thread's own mask.
        unsafe {
            let (mut allowed, mut near): (libc::cpu_set_t, libc::cpu_set_t) =
                (std::mem::zeroed(), std::mem::zeroed());
            if list.is_none()
                || libc::sched_getaffinity(0, std::mem::size_of::<libc::cpu_set_t>(), &mut allowed)
                    != 0
            {
                return Near(None);
            }
            for range in list.as_deref().unwrap_or_default().trim().split(',') {
                let (lo, hi) = range.split_once('-').unwrap_or((range, range));
                let (Ok(lo), Ok(hi)) = (lo.parse::<usize>(), hi.parse::<usize>()) else {
                    return Near(None);
                };
                for cpu in (lo..=hi).filter(|&cpu| {
                    cpu < libc::CPU_SETSIZE as usize && libc::CPU_ISSET(cpu, &allowed)
                }) {
                    libc::CPU_SET(cpu, &mut near);
                }
            }
            Near((libc::CPU_COUNT(&near) > 0).then_some(near))
        }
    }
    #[cfg(not(target_os = "linux"))]
    fn of(_: i32) -> Near {
        Near()
    }
    /// Moves this thread there (TensorFS's own threads only).
    fn enter(&self) {
        #[cfg(target_os = "linux")]
        if let Some(set) = &self.0 {
            // SAFETY: a valid mask for the calling thread.
            unsafe { libc::sched_setaffinity(0, std::mem::size_of::<libc::cpu_set_t>(), set) };
        }
    }
}

struct Engine {
    device: i32,
    ctx: CUcontext,
    streams: Vec<cuda::Stream>,
    queues: Vec<Mutex<()>>,
    near: Near,
    free: Mutex<Vec<Slot>>,
    serial: Mutex<()>,
    seen: Mutex<VecDeque<(usize, usize)>>,
    held: Mutex<Vec<Retained>>,
    staged: Mutex<Vec<Slot>>,
    /// Completed events of this context, reused: a run records a start and an end on every
    /// stream, and a wait for each foreign stream.
    events: Mutex<Vec<Event>>,
}

/// Completed events an engine keeps for reuse; more than this go.
const EVENTS: usize = 64;

/// A Varena working allocation. DLPack holders share it; completed decoder owners return it
/// directly. An unannotated final owner joins its primary context before permitting reuse.
pub struct DeviceBuffer {
    ptr: u64,
    len: usize,
    engine: Arc<Engine>,
    release_failed: bool,
}

impl DeviceBuffer {
    pub fn new(device: i32, len: usize) -> cuda::Result<DeviceBuffer> {
        let _producer = varena::enter_producer(device)?;
        let engine = Engine::get(device)?;
        let _ctx = CtxGuard::enter(engine.ctx)?;
        let ptr = cuda::allocate_ready(device, len)?;
        Ok(DeviceBuffer {
            ptr,
            len,
            engine,
            release_failed: false,
        })
    }
    pub fn ptr(&self) -> u64 {
        self.ptr
    }
    pub fn len(&self) -> usize {
        self.len
    }
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }
    pub fn device(&self) -> i32 {
        self.engine.device
    }
    pub fn context(&self) -> CUcontext {
        self.engine.ctx
    }
    /// Free a completed native-owned allocation, checking the driver result.
    ///
    /// # Safety
    /// Every producer and consumer is checked complete; no alias may access the pointer.
    /// The caller excludes actual CUDA capture. On error retain this owner until process
    /// retirement; an ambiguous free must not be retried, including by Drop.
    pub unsafe fn release_completed(&mut self) -> cuda::Result<()> {
        if self.release_failed {
            return Err(cuda::Error::CudaUnavailable(
                "allocation release was already unproven".into(),
            ));
        }
        if self.ptr == 0 {
            return Ok(());
        }
        self.release_failed = true;
        // SAFETY: the caller certified every use complete and exclusively owns the pointer.
        unsafe { varena::working::free_completed(self.engine.device, self.ptr) }?;
        self.ptr = 0;
        self.len = 0;
        self.release_failed = false;
        Ok(())
    }
}

impl Drop for DeviceBuffer {
    fn drop(&mut self) {
        if self.ptr != 0 && !self.release_failed {
            // Unknown DLPack consumers may still run. Varena records retirement without CUDA
            // work, including during capture, and joins the context before reuse or unmap.
            // SAFETY: this is the final native owner; no further submissions may use its pointer.
            let _ = unsafe { varena::working::free_untracked(self.engine.device, self.ptr) };
        }
        // A failed metadata transition leaves the live block retained by Varena.
    }
}

#[derive(Default)]
struct Retained {
    slots: Vec<Slot>,
    pins: Vec<cuda::HostPin>,
    events: Vec<Event>,
    streams: Vec<cuda::Stream>,
    _buffers: Vec<DeviceBuffer>,
}

// A failed check leaves the actual owners in place, not just their pointer identities.
fn checked_take<T, E>(
    owners: &mut Vec<T>,
    check: impl FnOnce(&mut [T]) -> Result<(), E>,
) -> Result<Vec<T>, E> {
    check(owners)?;
    Ok(std::mem::take(owners))
}

// A scoped reader may unwind before its normal ring return. Keep those actual slots
// in the engine's retained set instead of running GPU-owning Slot destructors there.
struct ReaderRing<'a> {
    engine: &'a Engine,
    slots: Vec<Slot>,
}
impl Drop for ReaderRing<'_> {
    fn drop(&mut self) {
        for slot in self.slots.drain(..) { self.engine.hold_slot(slot); }
    }
}

struct RunHold<'a> {
    engine: &'a Engine,
    owners: Option<Retained>,
}

impl RunHold<'_> {
    fn take(&mut self) -> Retained {
        let mut owners = self.owners.take().expect("run owners taken once");
        owners
            .slots
            .append(&mut self.engine.staged.lock().unwrap_or_else(|e| e.into_inner()));
        owners
    }

    fn finish(mut self, complete: bool) -> cuda::Result<()> {
        let owners = self.take();
        self.engine.release(vec![owners], complete)
    }
}

impl Drop for RunHold<'_> {
    fn drop(&mut self) {
        if self.owners.is_some() {
            let owners = self.take();
            self.engine
                .held
                .lock()
                .unwrap_or_else(|e| e.into_inner())
                .push(owners);
        }
    }
}

fn registry() -> &'static Mutex<BTreeMap<i32, Arc<Engine>>> {
    static ENGINES: OnceLock<Mutex<BTreeMap<i32, Arc<Engine>>>> = OnceLock::new();
    ENGINES.get_or_init(Mutex::default)
}

pub(super) fn prepare(device: i32) -> cuda::Result<()> {
    Engine::get(device).map(drop)
}

fn interrupted(copy: usize) -> Error {
    Error { copy, source: io::Error::new(io::ErrorKind::Interrupted, "native read canceled") }
}

/// Noninitializing: no driver/context is created when this device has no engine.
pub(super) fn drain(device: i32) -> cuda::Result<()> {
    let engine = registry()
        .lock()
        .unwrap_or_else(|e| e.into_inner())
        .get(&device)
        .cloned();
    match engine {
        Some(engine) => {
            let _serial = engine.serial.lock().unwrap_or_else(|e| e.into_inner());
            engine.recover()
        }
        None => Ok(()),
    }
}

#[cfg(feature = "store")]
pub(super) fn retain_decode(stream: Option<cuda::Stream>, buffers: Vec<DeviceBuffer>) {
    let engine = buffers
        .first()
        .expect("decode retains its output")
        .engine
        .clone();
    engine
        .held
        .lock()
        .unwrap_or_else(|e| e.into_inner())
        .push(Retained {
            streams: stream.into_iter().collect(),
            _buffers: buffers,
            ..Retained::default()
        });
}

// Handles are used only after entering their primary context; calls on a stream are ordered.
// SAFETY: handles are used only after entering their primary context, and calls on one stream are ordered by its lock.
unsafe impl Send for Engine {}
// SAFETY: as above.
unsafe impl Sync for Engine {}

impl Engine {
    fn get(device: i32) -> cuda::Result<Arc<Engine>> {
        let mut engines = registry().lock().unwrap_or_else(|e| e.into_inner());
        if let Some(engine) = engines.get(&device) {
            return Ok(engine.clone());
        }
        let streams: Vec<_> = (0..STREAMS)
            .map(|_| cuda::Stream::new(device))
            .collect::<cuda::Result<_>>()?;
        let ctx = streams[0].context();
        let near = Near::of(device);
        // Pinned pages land on the allocating thread's node.
        let at = ctx as usize;
        let free = std::thread::scope(|s| {
            s.spawn(|| {
                near.enter();
                let ctx = at as CUcontext;
                let _ctx = CtxGuard::enter(ctx)?;
                (0..STAGING)
                    .map(|_| Slot::new(ctx))
                    .collect::<cuda::Result<Vec<_>>>()
            })
            .join()
            .expect("staging allocation does not panic")
        })?;
        let engine = Arc::new(Engine {
            device,
            ctx,
            streams,
            queues: (0..STREAMS).map(|_| Mutex::new(())).collect(),
            near,
            free: Mutex::new(free),
            serial: Mutex::new(()),
            seen: Mutex::new(VecDeque::new()),
            held: Mutex::new(Vec::new()),
            staged: Mutex::new(Vec::new()),
            events: Mutex::new(Vec::new()),
        });
        engines.insert(device, engine.clone());
        Ok(engine)
    }

    fn reused(&self, ptr: usize, len: usize) -> bool {
        let mut seen = self.seen.lock().unwrap();
        if seen.contains(&(ptr, len)) {
            return true;
        }
        if seen.len() >= 256 {
            seen.pop_front();
        }
        seen.push_back((ptr, len));
        false
    }

    fn wait(&self, event: &Event, streams: usize) -> cuda::Result<()> {
        let _ctx = CtxGuard::enter(self.ctx)?;
        for stream in &self.streams[..streams] {
            // SAFETY: a live stream and event of this engine's context, which is current.
            cuda::check("cuStreamWaitEvent", unsafe {
                (cuda::driver()?.stream_wait_event)(stream.raw() as CUstream, event.raw, 0)
            })?;
        }
        Ok(())
    }

    fn synchronize(&self, owners: &[Retained]) -> cuda::Result<()> {
        let mut first = None;
        for stream in self
            .streams
            .iter()
            .chain(owners.iter().flat_map(|r| &r.streams))
        {
            if let Err(error) = stream.drain() {
                first.get_or_insert(error);
            }
        }
        first.map_or(Ok(()), Err)
    }

    fn checked_release(&self, owners: &mut [Retained], complete: bool) -> cuda::Result<()> {
        if !complete {
            self.synchronize(owners)?;
        }
        let mut first = None;
        for buffer in owners.iter_mut().flat_map(|r| &mut r._buffers) {
            // SAFETY: all private streams completed; these are quarantined private owners.
            if let Err(error) = unsafe { buffer.release_completed() } {
                first.get_or_insert(error);
            }
        }
        for pin in owners.iter_mut().flat_map(|r| &mut r.pins) {
            if let Err(error) = pin.release() {
                first.get_or_insert(error);
            }
        }
        first.map_or(Ok(()), Err)
    }

    fn released(&self, owners: Vec<Retained>) {
        for mut owner in owners {
            for mut slot in owner.slots.drain(..) {
                slot.pending = false;
                slot.recorded = false;
                self.free().push(slot);
            }
            // Checked complete: its events are free to record again.
            let mut pool = self.events.lock().unwrap_or_else(|e| e.into_inner());
            for event in owner.events.drain(..).filter(|e| e.ctx == self.ctx) {
                if pool.len() < EVENTS {
                    pool.push(event);
                }
            }
            drop(pool);
            // The remaining event/stream/allocation owners drop only after checked completion.
            drop(owner);
        }
    }

    fn release(&self, mut owners: Vec<Retained>, complete: bool) -> cuda::Result<()> {
        match checked_take(&mut owners, |r| self.checked_release(r, complete)) {
            Ok(released) => {
                self.released(released);
                Ok(())
            }
            Err(error) => {
                self.held
                    .lock()
                    .unwrap_or_else(|e| e.into_inner())
                    .extend(owners);
                Err(error)
            }
        }
    }

    // Caller holds serial, including before allowing any slot to be reused.
    fn recover(&self) -> cuda::Result<()> {
        let mut held = self.held.lock().unwrap_or_else(|e| e.into_inner());
        let released = checked_take(&mut held, |r| self.checked_release(r, false))?;
        drop(held);
        // All previous engine work is now complete, including slots already returned to the free list.
        for slot in self.free().iter_mut() {
            slot.pending = false;
            slot.recorded = false;
        }
        self.released(released);
        Ok(())
    }

    /// An event of this context, `timing` or not: a completed one again, else a new one.
    fn event(&self, timing: bool) -> cuda::Result<Event> {
        let reused = {
            let mut pool = self.events.lock().unwrap_or_else(|e| e.into_inner());
            pool.iter().position(|e| e.timing == timing).map(|at| pool.swap_remove(at))
        };
        reused.map_or_else(|| Event::new(self.ctx, timing), Ok)
    }

    fn free(&self) -> std::sync::MutexGuard<'_, Vec<Slot>> {
        self.free.lock().unwrap_or_else(|e| e.into_inner())
    }

    fn hold_slot(&self, slot: Slot) {
        self.staged
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .push(slot);
    }

    fn run(
        self: &Arc<Self>,
        copies: &[(usize, Copy)],
        opts: &ReadOpts,
        staged_host: bool,
        issued: Option<Issued>,
        cancel: Option<&ReadControl>,
        mut deferred: Option<&mut OwnedRead>,
    ) -> Result<ReadStats, Error> {
        let _serial = self.serial.lock().unwrap_or_else(|e| e.into_inner());
        let first = copies[0].0;
        let canceled = || cancel.is_some_and(ReadControl::canceled);
        if canceled() {
            return Err(interrupted(first));
        }
        if !self
            .held
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .is_empty()
        {
            if deferred.is_some() {
                return Err(Error { copy: first, source: io::Error::new(
                    io::ErrorKind::WouldBlock, "owned read cannot join prior unproven engine work",
                ) });
            }
            self.recover().map_err(|e| failed(first, e))?;
        }
        let _ctx = CtxGuard::enter(self.ctx).map_err(|e| failed(first, e))?;
        let streams = opts.streams.clamp(1, STREAMS);
        let owned_submission = deferred.is_some();
        let issued_bytes = AtomicU64::new(0);
        let queued = owned_submission.then_some(Queued { control: cancel, bytes: &issued_bytes });
        let mut hold = RunHold {
            engine: self,
            owners: Some(Retained::default()),
        };
        let mut complete = false;
        let mut timing = None;
        let mut submitted_stats = ReadStats::default();
        let mut recording_failure = None;
        let result = (|| {
            let owners = hold.owners.as_mut().expect("run owners live");
            let mut jobs = Vec::new();
            let tally = Tally::default();
            for (local, &(copy, c)) in copies.iter().enumerate() {
                if let Src::Device { device, stream, .. } = c.src {
                    let source = Engine::get(device).map_err(|e| failed(copy, e))?;
                    owners
                        .events
                        .push(Event::new(source.ctx, false).map_err(|e| failed(copy, e))?);
                    let event = owners.events.last().expect("source event inserted");
                    event
                        .record(stream as CUstream)
                        .map_err(|e| failed(copy, e))?;
                    self.wait(event, streams).map_err(|e| failed(copy, e))?;
                }
                if let Dst::Device { stream, .. } = c.dst {
                    // Owned raw Fills are exclusive fresh destinations. Their explicit
                    // engine stream is a producer identity, not a prior consumer dependency.
                    if deferred.is_none() && stream != 0 {
                        owners
                            .events
                            .push(self.event(false).map_err(|e| failed(copy, e))?);
                        let event = owners.events.last().expect("destination event inserted");
                        event
                            .record(stream as CUstream)
                            .map_err(|e| failed(copy, e))?;
                        self.wait(event, streams).map_err(|e| failed(copy, e))?;
                    }
                }
                let mut direct = matches!(
                    (c.src, c.dst),
                    (Src::Device { .. } | Src::Zero, Dst::Device { .. })
                );
                if !staged_host {
                    if let (Src::Host(ptr), Dst::Device { .. }) = (c.src, c.dst) {
                        let reused = self.reused(ptr as usize, c.dst.len());
                        // SAFETY: `ptr` is the caller's live host source for this read (read's contract).
                        if unsafe { cuda::registered(ptr) }.map_err(|e| failed(copy, e))? {
                            direct = true;
                        } else if reused {
                            let start = Instant::now();
                            let pin =
                                // SAFETY: `[ptr, ptr+len)` is the caller's live host source until the copy completes (read's contract).
                                unsafe { cuda::pin_region(ptr.cast_mut(), c.dst.len(), true) };
                            tally
                                .pin_ns
                                .fetch_add(start.elapsed().as_nanos() as u64, Relaxed);
                            if let Ok(pin) = pin {
                                owners.pins.push(pin);
                                direct = true;
                            }
                        }
                    }
                }
                let step = if direct { c.dst.len() } else { PIECE };
                for at in (0..c.dst.len()).step_by(step.max(1)) {
                    jobs.push(Job {
                        copy,
                        local,
                        c,
                        at,
                        len: step.min(c.dst.len() - at),
                        direct,
                    });
                }
            }
            let start = owners.events.len();
            for stream in &self.streams[..streams] {
                owners
                    .events
                    .push(self.event(true).map_err(|e| failed(first, e))?);
                owners
                    .events
                    .last()
                    .expect("start event inserted")
                    .record(stream.raw() as CUstream)
                    .map_err(|e| failed(first, e))?;
            }
            let next = AtomicUsize::new(0);
            let stopped = AtomicBool::new(false);
            let error = Mutex::new(None);
            // Each copy's jobs not yet issued: the one that issues its last tells `issued`.
            let left: Vec<AtomicUsize> = (0..copies.len()).map(|_| AtomicUsize::new(0)).collect();
            jobs.iter().for_each(|job| _ = left[job.local].fetch_add(1, Relaxed));
            let raw: Vec<usize> = self.streams[..streams].iter().map(|s| s.raw()).collect();
            let done = |job: &Job| {
                if !owned_submission {
                    if let Some(control) = cancel { control.issue(job.len); }
                }
                if let Some(issued) = issued {
                    if left[job.local].fetch_sub(1, AcqRel) == 1 {
                        issued(job.copy, &raw);
                    }
                }
            };
            // Direct copies (device, zero or registered host sources) need no staging: this
            // thread issues them, round-robin over the streams, before any reader starts.
            let (direct, jobs): (Vec<Job>, Vec<Job>) = jobs.into_iter().partition(|job| job.direct);
            for (at, job) in direct.iter().enumerate() {
                if canceled() {
                    error.lock().unwrap().get_or_insert_with(|| interrupted(first));
                    stopped.store(true, Relaxed);
                    break;
                }
                if let Err(failure) = self.issue(job, lane(at, streams)) {
                    error.lock().unwrap().get_or_insert(failure);
                    stopped.store(true, Relaxed);
                    break;
                }
                if let Some(queued) = queued { queued.issue(job.len); }
                done(job);
            }
            // A failed copy's slots stay retained until checked completion: read with the rest.
            let readers = readers(jobs.len(), opts, self.free().len());
            if readers == 0 && !jobs.is_empty() && !stopped.load(Relaxed) {
                let lost = io::Error::other("all staging is still retained by failed copies");
                return Err(Error {
                    copy: first,
                    source: lost,
                });
            }
            let work = || {
                self.near.enter();
                let mut ring = ReaderRing {
                    engine: self,
                    slots: {
                        let mut free = self.free();
                        let at = free.len() - RING;
                        free.split_off(at)
                    },
                };
                let mut turn = 0;
                while !stopped.load(Relaxed) && !canceled() {
                    let at = next.fetch_add(1, Relaxed);
                    let Some(job) = jobs.get(at) else { break };
                    turn += 1;
                        match self.piece(job, at % streams, opts, &tally, &mut ring.slots[turn % RING],
                            queued) {
                        Ok(()) => done(job),
                        Err(failure) => {
                            error.lock().unwrap().get_or_insert(failure);
                            stopped.store(true, Relaxed);
                        }
                    }
                }
                // After any failure a slot may still be in flight: kept until checked completion.
                for slot in ring.slots.drain(..) {
                    match stopped.load(Relaxed) {
                        true => self.hold_slot(slot),
                        false => self.free().push(slot),
                    }
                }
            };
            // Every reader is TensorFS's own thread, so moving it to the GPU's CPUs moves no caller.
            std::thread::scope(|scope| {
                for _ in 0..readers {
                    scope.spawn(work);
                }
            });
            if canceled() {
                error.lock().unwrap().get_or_insert_with(|| interrupted(first));
            }
            let mut busy_ns = 0;
            let mut all_complete = true;
            let mut ends = Vec::new();
            for (lane, stream) in self.streams[..streams].iter().enumerate() {
                let drained = (|| {
                    owners.events.push(self.event(true)?);
                    let index = owners.events.len() - 1;
                    let end = &owners.events[index];
                    end.record(stream.raw() as CUstream)?;
                    ends.push(index); // Only successfully recorded events certify submission.
                    if deferred.is_some() {
                        Ok(0)
                    } else {
                        end.sync()?;
                        end.since(&owners.events[start + lane])
                    }
                })();
                match drained {
                    Ok(ns) => busy_ns += ns,
                    Err(e) => {
                        all_complete = false;
                        recording_failure.get_or_insert_with(|| e.clone());
                        error.lock().unwrap().get_or_insert(failed(first, e));
                    }
                }
            }
            timing = Some((Some(start), ends, all_complete));
            complete = all_complete && deferred.is_none();
            submitted_stats = ReadStats {
                direct: tally.direct.load(Relaxed),
                cached: tally.cached.load(Relaxed),
                bounced: tally.bounced.load(Relaxed),
                pin_ns: tally.pin_ns.load(Relaxed),
                staged: tally.staged.load(Relaxed),
                busy_ns,
                ..ReadStats::default()
            };
            if let Some(error) = error.into_inner().unwrap() {
                return Err(error);
            }
            Ok(submitted_stats)
        })();
        if let Some(deferred) = deferred.as_mut() {
            // An early ordinary error can follow direct zero copies or recorded start
            // events. Close the exact stream set even on that path; an unrecorded event
            // can never certify completion or return to the completed-event pool.
            if timing.is_none() {
                let owners = hold.owners.as_mut().expect("run owners live");
                let mut ends = Vec::new();
                let mut recorded = true;
                for stream in &self.streams[..streams] {
                    let closed = (|| {
                        owners.events.push(self.event(false)?);
                        let index = owners.events.len() - 1;
                        owners.events[index].record(stream.raw() as CUstream)?;
                        ends.push(index);
                        Ok::<_, cuda::Error>(())
                    })();
                    if let Err(error) = closed {
                        recorded = false;
                        recording_failure.get_or_insert(error);
                    }
                }
                timing = Some((None, ends, recorded));
            }
            // Every scoped CPU reader has joined on every normal return. This transfers
            // actual custody, without a stream/context wait or an engine recovery call.
            deferred.close(hold.take(), timing, submitted_stats, issued_bytes.load(Relaxed), recording_failure);
            return result;
        }
        let released = hold.finish(complete).map_err(|e| failed(first, e));
        let stats = result?;
        released?;
        Ok(stats)
    }

    /// A direct copy, whole, on stream `lane`: a memset, a device copy, a peer copy or a copy
    /// from registered host memory. Nothing is staged.
    fn issue(&self, job: &Job, lane: usize) -> Result<(), Error> {
        let _ctx = CtxGuard::enter(self.ctx).map_err(|e| failed(job.copy, e))?;
        let d = cuda::driver().map_err(|e| failed(job.copy, e))?;
        let stream = self.streams[lane].raw() as CUstream;
        let _queue = self.queues[lane].lock().unwrap();
        let Dst::Device { ptr: dst, .. } = job.c.dst else {
            unreachable!("a direct copy has a device destination")
        };
        let result = match job.c.src {
            // SAFETY: the checked destination covers job.len bytes and remains owned until drain.
            Src::Zero => unsafe { (d.memset_d8_async)(dst, 0, job.len, stream) },
            // SAFETY: direct host sources are registered and retained through checked completion.
            Src::Host(ptr) => unsafe { (d.memcpy_htod_async)(dst, ptr.cast(), job.len, stream) },
            // SAFETY: both checked device spans belong to this context and outlive the copy.
            Src::Device { device, ptr, .. } if device == self.device => unsafe {
                (d.memcpy_dtod_async)(dst, ptr, job.len, stream)
            },
            Src::Device { device, ptr, .. } => {
                let source = Engine::get(device).map_err(|e| failed(job.copy, e))?;
                // SAFETY: both contexts and checked peer spans stay owned until completion.
                unsafe { (d.memcpy_peer_async)(dst, self.ctx, ptr, source.ctx, job.len, stream) }
            }
            Src::File(..) => unreachable!("a file source is staged"),
        };
        cuda::check("cuMemcpyAsync", result).map_err(|e| failed(job.copy, e))
    }

    fn piece(
        &self,
        job: &Job,
        lane: usize,
        opts: &ReadOpts,
        tally: &Tally,
        slot: &mut Slot,
        queued: Option<Queued<'_>>,
    ) -> Result<(), Error> {
        let _ctx = CtxGuard::enter(self.ctx).map_err(|e| failed(job.copy, e))?;
        let d = cuda::driver().map_err(|e| failed(job.copy, e))?;
        let stream = self.streams[lane].raw() as CUstream;
        if slot.pending {
            slot.done.sync().map_err(|e| failed(job.copy, e))?;
            slot.pending = false;
        }
        match job.c.src {
            Src::File(file, offset) => {
                let copy = Copy {
                    src: Src::File(file, offset + job.at as u64),
                    dst: Dst::Host {
                        ptr: slot.ptr,
                        len: job.len,
                    },
                };
                let options = ReadOpts {
                    threads: 1,
                    ..opts.clone()
                };
                // SAFETY: the staging slot is this engine's own and the source is the caller's (read's contract).
                let stats = unsafe { host::fill(&[copy], &options, None) }.map_err(|e| Error {
                    copy: job.copy,
                    source: e.source,
                })?;
                tally.direct.fetch_add(stats.direct, Relaxed);
                tally.cached.fetch_add(stats.cached, Relaxed);
                tally.bounced.fetch_add(stats.bounced, Relaxed);
            }
            // SAFETY: the host source covers `job.at + job.len` bytes (read's contract) and the slot holds `PIECE >= job.len`.
            Src::Host(ptr) => unsafe {
                std::ptr::copy_nonoverlapping(ptr.add(job.at), slot.ptr, job.len)
            },
            Src::Device { .. } => {}
            Src::Zero => unreachable!("zero uses native device memset"),
        }
        let _queue = self.queues[lane].lock().unwrap();
        let rc = match (job.c.src, job.c.dst) {
            // SAFETY: the device destination covers `job.at + job.len` bytes and the slot stays pending until the event syncs.
            (_, Dst::Device { ptr, .. }) => unsafe {
                (d.memcpy_htod_async)(ptr + job.at as u64, slot.ptr.cast(), job.len, stream)
            },
            // SAFETY: the device source covers `job.at + job.len` bytes and the slot stays pending until the event syncs.
            (Src::Device { ptr, .. }, Dst::Host { .. }) => unsafe {
                (d.memcpy_dtoh_async)(slot.ptr.cast(), ptr + job.at as u64, job.len, stream)
            },
            _ => unreachable!(),
        };
        slot.pending = true;
        slot.recorded = false;
        cuda::check("cuMemcpyAsync", rc).map_err(|e| failed(job.copy, e))?;
        // Count a successful device enqueue even if its following tracking-event record
        // fails. Zero counted bytes is never an unknown-completion certificate.
        if let Some(queued) = queued { queued.issue(job.len); }
        slot.done.record(stream).map_err(|e| failed(job.copy, e))?;
        slot.recorded = true;
        if let Dst::Host { ptr, .. } = job.c.dst {
            slot.done.sync().map_err(|e| failed(job.copy, e))?;
            slot.pending = false;
            // SAFETY: the copy into the slot completed (synced above); the host destination covers `job.at + job.len` bytes.
            unsafe { std::ptr::copy_nonoverlapping(slot.ptr, ptr.add(job.at), job.len) };
        }
        tally.staged.fetch_add(job.len as u64, Relaxed);
        Ok(())
    }
}

/// The stream the `at`-th direct copy of a run goes on: round-robin over the run's `streams`.
fn lane(at: usize, streams: usize) -> usize {
    at % streams.max(1)
}

/// Reader threads a run starts for its `staged` pieces: none without any, else as many as its
/// threads allow and the free staging rings hold.
fn readers(staged: usize, opts: &ReadOpts, free_slots: usize) -> usize {
    opts.threads.clamp(1, READERS).min(staged).min(free_slots / RING)
}

#[derive(Clone, Copy)]
struct Queued<'a> {
    control: Option<&'a ReadControl>,
    bytes: &'a AtomicU64,
}
impl Queued<'_> {
    fn issue(self, len: usize) {
        self.bytes.fetch_add(len as u64, Relaxed);
        if let Some(control) = self.control { control.issue(len); }
    }
}

struct Job<'a> {
    copy: usize,
    /// Its copy's place in the run.
    local: usize,
    c: Copy<'a>,
    at: usize,
    len: usize,
    direct: bool,
}

#[derive(Default)]
struct Tally {
    direct: AtomicU64,
    cached: AtomicU64,
    bounced: AtomicU64,
    pin_ns: AtomicU64,
    staged: AtomicU64,
}

/// Same bounded B7 staging, with checked completion and retained native resources on error.
pub(super) unsafe fn fill(
    copies: &[(usize, Copy)],
    opts: &ReadOpts,
    staged_host: bool,
    issued: Option<Issued>,
    cancel: Option<&ReadControl>,
) -> Result<ReadStats, Error> {
    let mut groups: BTreeMap<(i32, &str), Vec<(usize, Copy)>> = BTreeMap::new();
    for &(index, copy) in copies {
        if copy.dst.is_empty() {
            continue;
        }
        let device = match (copy.src, copy.dst) {
            (_, Dst::Device { device, .. }) | (Src::Device { device, .. }, _) => device,
            _ => unreachable!(),
        };
        let kind = match (copy.src, copy.dst) {
            (Src::Zero, _) => "zero",
            (Src::Device { .. }, Dst::Host { .. }) => "d2h",
            (Src::Device { device: source, .. }, Dst::Device { device: target, .. })
                if source != target =>
            {
                "peer"
            }
            (Src::Device { .. }, Dst::Device { .. }) => "d2d",
            _ => "h2d",
        };
        groups
            .entry((device, kind))
            .or_default()
            .push((index, copy));
    }
    let mut total = ReadStats::default();
    // Zeroes first: a placement's padding is done before its file bytes go out, so the last of
    // those (`issued`) completes it.
    let mut groups: Vec<_> = groups.into_iter().collect();
    groups.sort_by_key(|((_, kind), _)| *kind != "zero");
    for ((device, kind), copies) in groups {
        let engine = Engine::get(device).map_err(|e| failed(copies[0].0, e))?;
        let start = Instant::now();
        let stats = engine.run(&copies, opts, staged_host, issued, cancel, None)?;
        #[cfg(unix)]
        {
            let ns = start.elapsed().as_nanos() as u64;
            let plain: Vec<Copy> = copies.iter().map(|&(_, c)| c).collect();
            super::disk_run(&plain, &stats, ns);
            let run = super::metrics::Copy {
                kind,
                gpu: device,
                bytes: copies.iter().map(|(_, c)| c.dst.len() as u64).sum(),
                ns,
                link: super::metrics::device_link(device)
                    .map_or_else(String::new, |link| link.to_string()),
                busy_ns: stats.busy_ns,
                pin_ns: stats.pin_ns,
                staged: stats.staged,
                cached: stats.cached,
                ..Default::default()
            };
            match kind {
                "h2d" => super::metrics::h2d_run(run),
                _ => super::metrics::record(run),
            }
        }
        #[cfg(not(unix))]
        let _ = (kind, start);
        total.direct += stats.direct;
        total.cached += stats.cached;
        total.bounced += stats.bounced;
        total.pin_ns += stats.pin_ns;
        total.staged += stats.staged;
        total.busy_ns += stats.busy_ns;
    }
    Ok(total)
}
